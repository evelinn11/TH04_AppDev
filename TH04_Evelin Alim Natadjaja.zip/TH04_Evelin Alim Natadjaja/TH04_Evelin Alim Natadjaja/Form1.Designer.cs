﻿namespace TH04_Evelin_Alim_Natadjaja
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_SoccerTeamList = new System.Windows.Forms.Label();
            this.lb_ChooseCountry = new System.Windows.Forms.Label();
            this.lb_ChooseTeam = new System.Windows.Forms.Label();
            this.cBox_ChooseCountry = new System.Windows.Forms.ComboBox();
            this.cBox_ChooseTeam = new System.Windows.Forms.ComboBox();
            this.lBox_Player = new System.Windows.Forms.ListBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.lb_TeamCity = new System.Windows.Forms.Label();
            this.lb_TeamCountry = new System.Windows.Forms.Label();
            this.lb_TeamName = new System.Windows.Forms.Label();
            this.tB_TeamName = new System.Windows.Forms.TextBox();
            this.tB_TeamCountry = new System.Windows.Forms.TextBox();
            this.tB_TeamCity = new System.Windows.Forms.TextBox();
            this.lb_AddingTeam = new System.Windows.Forms.Label();
            this.lb_AddingPlayers = new System.Windows.Forms.Label();
            this.tB_PlayerNumber = new System.Windows.Forms.TextBox();
            this.tB_PlayerName = new System.Windows.Forms.TextBox();
            this.lb_PlayerPosition = new System.Windows.Forms.Label();
            this.lb_PlayerNumber = new System.Windows.Forms.Label();
            this.lb_PlayerName = new System.Windows.Forms.Label();
            this.cBox_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.btn_AddPlayer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_SoccerTeamList
            // 
            this.lb_SoccerTeamList.AutoSize = true;
            this.lb_SoccerTeamList.Location = new System.Drawing.Point(12, 42);
            this.lb_SoccerTeamList.Name = "lb_SoccerTeamList";
            this.lb_SoccerTeamList.Size = new System.Drawing.Size(90, 13);
            this.lb_SoccerTeamList.TabIndex = 0;
            this.lb_SoccerTeamList.Text = "Soccer Team List";
            // 
            // lb_ChooseCountry
            // 
            this.lb_ChooseCountry.AutoSize = true;
            this.lb_ChooseCountry.Location = new System.Drawing.Point(12, 77);
            this.lb_ChooseCountry.Name = "lb_ChooseCountry";
            this.lb_ChooseCountry.Size = new System.Drawing.Size(88, 13);
            this.lb_ChooseCountry.TabIndex = 1;
            this.lb_ChooseCountry.Text = " Choose Country:";
            // 
            // lb_ChooseTeam
            // 
            this.lb_ChooseTeam.AutoSize = true;
            this.lb_ChooseTeam.Location = new System.Drawing.Point(12, 113);
            this.lb_ChooseTeam.Name = "lb_ChooseTeam";
            this.lb_ChooseTeam.Size = new System.Drawing.Size(79, 13);
            this.lb_ChooseTeam.TabIndex = 2;
            this.lb_ChooseTeam.Text = " Choose Team:";
            // 
            // cBox_ChooseCountry
            // 
            this.cBox_ChooseCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_ChooseCountry.FormattingEnabled = true;
            this.cBox_ChooseCountry.Location = new System.Drawing.Point(106, 74);
            this.cBox_ChooseCountry.Name = "cBox_ChooseCountry";
            this.cBox_ChooseCountry.Size = new System.Drawing.Size(108, 21);
            this.cBox_ChooseCountry.TabIndex = 3;
            this.cBox_ChooseCountry.SelectionChangeCommitted += new System.EventHandler(this.cBox_ChooseCountry_SelectionChangeCommitted);
            // 
            // cBox_ChooseTeam
            // 
            this.cBox_ChooseTeam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_ChooseTeam.FormattingEnabled = true;
            this.cBox_ChooseTeam.Location = new System.Drawing.Point(106, 110);
            this.cBox_ChooseTeam.Name = "cBox_ChooseTeam";
            this.cBox_ChooseTeam.Size = new System.Drawing.Size(108, 21);
            this.cBox_ChooseTeam.TabIndex = 4;
            this.cBox_ChooseTeam.SelectionChangeCommitted += new System.EventHandler(this.cBox_ChooseTeam_SelectionChangeCommitted);
            // 
            // lBox_Player
            // 
            this.lBox_Player.FormattingEnabled = true;
            this.lBox_Player.Location = new System.Drawing.Point(19, 165);
            this.lBox_Player.Name = "lBox_Player";
            this.lBox_Player.Size = new System.Drawing.Size(195, 108);
            this.lBox_Player.TabIndex = 5;
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(18, 279);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(73, 21);
            this.btn_Remove.TabIndex = 6;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // lb_TeamCity
            // 
            this.lb_TeamCity.AutoSize = true;
            this.lb_TeamCity.Location = new System.Drawing.Point(253, 145);
            this.lb_TeamCity.Name = "lb_TeamCity";
            this.lb_TeamCity.Size = new System.Drawing.Size(60, 13);
            this.lb_TeamCity.TabIndex = 9;
            this.lb_TeamCity.Text = " Team City:";
            // 
            // lb_TeamCountry
            // 
            this.lb_TeamCountry.AutoSize = true;
            this.lb_TeamCountry.Location = new System.Drawing.Point(253, 109);
            this.lb_TeamCountry.Name = "lb_TeamCountry";
            this.lb_TeamCountry.Size = new System.Drawing.Size(79, 13);
            this.lb_TeamCountry.TabIndex = 8;
            this.lb_TeamCountry.Text = "Team Country: ";
            // 
            // lb_TeamName
            // 
            this.lb_TeamName.AutoSize = true;
            this.lb_TeamName.Location = new System.Drawing.Point(253, 74);
            this.lb_TeamName.Name = "lb_TeamName";
            this.lb_TeamName.Size = new System.Drawing.Size(68, 13);
            this.lb_TeamName.TabIndex = 7;
            this.lb_TeamName.Text = "Team Name:";
            // 
            // tB_TeamName
            // 
            this.tB_TeamName.Location = new System.Drawing.Point(337, 70);
            this.tB_TeamName.Name = "tB_TeamName";
            this.tB_TeamName.Size = new System.Drawing.Size(108, 20);
            this.tB_TeamName.TabIndex = 10;
            // 
            // tB_TeamCountry
            // 
            this.tB_TeamCountry.Location = new System.Drawing.Point(337, 106);
            this.tB_TeamCountry.Name = "tB_TeamCountry";
            this.tB_TeamCountry.Size = new System.Drawing.Size(108, 20);
            this.tB_TeamCountry.TabIndex = 11;
            // 
            // tB_TeamCity
            // 
            this.tB_TeamCity.Location = new System.Drawing.Point(337, 142);
            this.tB_TeamCity.Name = "tB_TeamCity";
            this.tB_TeamCity.Size = new System.Drawing.Size(108, 20);
            this.tB_TeamCity.TabIndex = 12;
            // 
            // lb_AddingTeam
            // 
            this.lb_AddingTeam.AutoSize = true;
            this.lb_AddingTeam.Location = new System.Drawing.Point(334, 42);
            this.lb_AddingTeam.Name = "lb_AddingTeam";
            this.lb_AddingTeam.Size = new System.Drawing.Size(70, 13);
            this.lb_AddingTeam.TabIndex = 13;
            this.lb_AddingTeam.Text = "Adding Team";
            // 
            // lb_AddingPlayers
            // 
            this.lb_AddingPlayers.AutoSize = true;
            this.lb_AddingPlayers.Location = new System.Drawing.Point(542, 42);
            this.lb_AddingPlayers.Name = "lb_AddingPlayers";
            this.lb_AddingPlayers.Size = new System.Drawing.Size(77, 13);
            this.lb_AddingPlayers.TabIndex = 20;
            this.lb_AddingPlayers.Text = "Adding Players";
            // 
            // tB_PlayerNumber
            // 
            this.tB_PlayerNumber.Location = new System.Drawing.Point(545, 106);
            this.tB_PlayerNumber.Name = "tB_PlayerNumber";
            this.tB_PlayerNumber.Size = new System.Drawing.Size(109, 20);
            this.tB_PlayerNumber.TabIndex = 18;
            // 
            // tB_PlayerName
            // 
            this.tB_PlayerName.Location = new System.Drawing.Point(545, 70);
            this.tB_PlayerName.Name = "tB_PlayerName";
            this.tB_PlayerName.Size = new System.Drawing.Size(108, 20);
            this.tB_PlayerName.TabIndex = 17;
            // 
            // lb_PlayerPosition
            // 
            this.lb_PlayerPosition.AutoSize = true;
            this.lb_PlayerPosition.Location = new System.Drawing.Point(461, 145);
            this.lb_PlayerPosition.Name = "lb_PlayerPosition";
            this.lb_PlayerPosition.Size = new System.Drawing.Size(76, 13);
            this.lb_PlayerPosition.TabIndex = 16;
            this.lb_PlayerPosition.Text = "Player Position";
            // 
            // lb_PlayerNumber
            // 
            this.lb_PlayerNumber.AutoSize = true;
            this.lb_PlayerNumber.Location = new System.Drawing.Point(461, 109);
            this.lb_PlayerNumber.Name = "lb_PlayerNumber";
            this.lb_PlayerNumber.Size = new System.Drawing.Size(76, 13);
            this.lb_PlayerNumber.TabIndex = 15;
            this.lb_PlayerNumber.Text = "Player Number";
            // 
            // lb_PlayerName
            // 
            this.lb_PlayerName.AutoSize = true;
            this.lb_PlayerName.Location = new System.Drawing.Point(461, 74);
            this.lb_PlayerName.Name = "lb_PlayerName";
            this.lb_PlayerName.Size = new System.Drawing.Size(70, 13);
            this.lb_PlayerName.TabIndex = 14;
            this.lb_PlayerName.Text = "Player Name:";
            // 
            // cBox_PlayerPosition
            // 
            this.cBox_PlayerPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBox_PlayerPosition.FormattingEnabled = true;
            this.cBox_PlayerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cBox_PlayerPosition.Location = new System.Drawing.Point(545, 142);
            this.cBox_PlayerPosition.Name = "cBox_PlayerPosition";
            this.cBox_PlayerPosition.Size = new System.Drawing.Size(108, 21);
            this.cBox_PlayerPosition.TabIndex = 21;
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.Location = new System.Drawing.Point(337, 178);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(73, 21);
            this.btn_AddTeam.TabIndex = 22;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = true;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // btn_AddPlayer
            // 
            this.btn_AddPlayer.Location = new System.Drawing.Point(545, 178);
            this.btn_AddPlayer.Name = "btn_AddPlayer";
            this.btn_AddPlayer.Size = new System.Drawing.Size(73, 21);
            this.btn_AddPlayer.TabIndex = 23;
            this.btn_AddPlayer.Text = "Add";
            this.btn_AddPlayer.UseVisualStyleBackColor = true;
            this.btn_AddPlayer.Click += new System.EventHandler(this.btn_AddPlayer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 310);
            this.Controls.Add(this.btn_AddPlayer);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.cBox_PlayerPosition);
            this.Controls.Add(this.lb_AddingPlayers);
            this.Controls.Add(this.tB_PlayerNumber);
            this.Controls.Add(this.tB_PlayerName);
            this.Controls.Add(this.lb_PlayerPosition);
            this.Controls.Add(this.lb_PlayerNumber);
            this.Controls.Add(this.lb_PlayerName);
            this.Controls.Add(this.lb_AddingTeam);
            this.Controls.Add(this.tB_TeamCity);
            this.Controls.Add(this.tB_TeamCountry);
            this.Controls.Add(this.tB_TeamName);
            this.Controls.Add(this.lb_TeamCity);
            this.Controls.Add(this.lb_TeamCountry);
            this.Controls.Add(this.lb_TeamName);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.lBox_Player);
            this.Controls.Add(this.cBox_ChooseTeam);
            this.Controls.Add(this.cBox_ChooseCountry);
            this.Controls.Add(this.lb_ChooseTeam);
            this.Controls.Add(this.lb_ChooseCountry);
            this.Controls.Add(this.lb_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_SoccerTeamList;
        private System.Windows.Forms.Label lb_ChooseCountry;
        private System.Windows.Forms.Label lb_ChooseTeam;
        private System.Windows.Forms.ComboBox cBox_ChooseCountry;
        private System.Windows.Forms.ComboBox cBox_ChooseTeam;
        private System.Windows.Forms.ListBox lBox_Player;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Label lb_TeamCity;
        private System.Windows.Forms.Label lb_TeamCountry;
        private System.Windows.Forms.Label lb_TeamName;
        private System.Windows.Forms.TextBox tB_TeamName;
        private System.Windows.Forms.TextBox tB_TeamCountry;
        private System.Windows.Forms.TextBox tB_TeamCity;
        private System.Windows.Forms.Label lb_AddingTeam;
        private System.Windows.Forms.Label lb_AddingPlayers;
        private System.Windows.Forms.TextBox tB_PlayerNumber;
        private System.Windows.Forms.TextBox tB_PlayerName;
        private System.Windows.Forms.Label lb_PlayerPosition;
        private System.Windows.Forms.Label lb_PlayerNumber;
        private System.Windows.Forms.Label lb_PlayerName;
        private System.Windows.Forms.ComboBox cBox_PlayerPosition;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Button btn_AddPlayer;
    }
}


﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TH04_Evelin_Alim_Natadjaja
{
    public partial class Form1 : Form
    {
        List<Team> soccerTeams = new List<Team>();
        Team dataTim;

        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //default 3 team
            soccerTeams.Add(new Team("Manchester City", "England", "Manchester"));
            soccerTeams.Add(new Team("Arsenal", "England", "London"));
            soccerTeams.Add(new Team("Real Madrid", "Spain", "Madrid"));

            //default player manchester city
            soccerTeams[0].AddPemain("(33)", "Scott Carson,", "GK");
            soccerTeams[0].AddPemain("(31)", "Ederson,", "GK");
            soccerTeams[0].AddPemain("(06)", "Nathan Ake,", "DF");
            soccerTeams[0].AddPemain("(25)", "Manuel Akanji,", "DF");
            soccerTeams[0].AddPemain("(03)", "Ruben Dias,", "DF");
            soccerTeams[0].AddPemain("(21)", "Sergio Gomez,", "DF");
            soccerTeams[0].AddPemain("(17)", "Kevin de Bruyne,", "MF");
            soccerTeams[0].AddPemain("(11)", "Jeremy Doku,", "MF");
            soccerTeams[0].AddPemain("(10)", "Jack Grealish,", "MF");
            soccerTeams[0].AddPemain("(09)", "Erling Haaland,", "FW");
            soccerTeams[0].AddPemain("(19)", "Julian Alvarez,", "FW");

            //default player arsenal
            soccerTeams[1].AddPemain("(01)", "Aaron Ramsdale,", "GK");
            soccerTeams[1].AddPemain("(12)", "Jurrien Timber,", "DF");
            soccerTeams[1].AddPemain("(02)", "William Saliba,", "DF");
            soccerTeams[1].AddPemain("(04)", "Ben White,", "DF");
            soccerTeams[1].AddPemain("(15)", "Jakub Kiwior,", "DF");
            soccerTeams[1].AddPemain("(08)", "Martin Odegaard,", "MF");
            soccerTeams[1].AddPemain("(10)", "Emile Smith Rowe,", "MF");
            soccerTeams[1].AddPemain("(29)", "Kai Havertz,", "MF");
            soccerTeams[1].AddPemain("(11)", "Gabriel Martinelli,", "FW");
            soccerTeams[1].AddPemain("(24)", "Reiss Nelson,", "FW");
            soccerTeams[1].AddPemain("(07)", "Bukayo Saka,", "FW");

            //default player real madrid
            soccerTeams[2].AddPemain("(01)", "Thibaut Courtois,", "GK");
            soccerTeams[2].AddPemain("(02)", "Daniel Carvajal,", "DF");
            soccerTeams[2].AddPemain("(04)", "David Alaba,", "DF");
            soccerTeams[2].AddPemain("(17)", "Lucas Vázquez,", "DF");
            soccerTeams[2].AddPemain("(23)", "Ferland Mendy,", "DF");
            soccerTeams[2].AddPemain("(19)", "Daniel Ceballos,", "MF");
            soccerTeams[2].AddPemain("(15)", "Federico Valverde,", "MF");
            soccerTeams[2].AddPemain("(10)", "Luka Modric,", "MF");
            soccerTeams[2].AddPemain("(07)", "Vinicius Jr,", "FW");
            soccerTeams[2].AddPemain("(11)", "Rodrygo Goes,", "FW");
            soccerTeams[2].AddPemain("(14)", "Joselu Mato,", "FW");

            cBox_ChooseCountry.Items.Add(soccerTeams[0].teamCountry);
            cBox_ChooseCountry.Items.Add(soccerTeams[2].teamCountry);
        }

        void AddTeam(string namaTim, string asalNegara, string asalKota)
        {
            //add objek baru ke list objek sm parameternya
            dataTim = new Team(namaTim, asalNegara, asalKota);
            soccerTeams.Add(dataTim);

            //cek negara yang kembar
            bool kembar = false;
            for (int i = 0; i < soccerTeams.Count - 1; i++)
            {
                if (soccerTeams[i].teamCountry == soccerTeams[soccerTeams.Count - 1].teamCountry)
                {
                    kembar = true;
                }                
            }

            // kalo ga ada yang kembar di add ke combo boxnya country
            if (kembar == false)
            {
                cBox_ChooseCountry.Items.Add(dataTim.teamCountry);
            }
        }

        private void cBox_ChooseCountry_SelectionChangeCommitted(object sender, EventArgs e)
        {
            //waktu uda select country
            cBox_ChooseTeam.SelectedItem = null;
            cBox_ChooseTeam.Items.Clear();;
            if (cBox_ChooseCountry.SelectedItem != null)
            {
                //cek kalo country yang diselect itu sama kek list team index tertentu
                for (int j = 0; j < soccerTeams.Count; j++)
                {
                    if (cBox_ChooseCountry.SelectedItem.ToString() == soccerTeams[j].teamCountry)
                    {
                        cBox_ChooseTeam.Items.Add(soccerTeams[j].teamName);
                    }
                }
            }
        }

        private void cBox_ChooseTeam_SelectionChangeCommitted(object sender, EventArgs e)
        {
            int i;
            lBox_Player.Items.Clear();
            //i = buat index teamnya yang dimasukin for j dan cek i yang dimau
            for (i = 0; i < soccerTeams.Count; i++)
            {
                if (soccerTeams[i].teamName == cBox_ChooseTeam.SelectedItem.ToString())
                {
                    break;
                }
            }
            //buat tampilin di listbox
            for (int j = 0; j < soccerTeams[i].Players.Count; j++)
            {
                lBox_Player.Items.Add(soccerTeams[i].Players[j].playerNum + " " +
                        soccerTeams[i].Players[j].playerName + " " +
                        soccerTeams[i].Players[j].playerPos);
                lBox_Player.Sorted = true;
            }
        }

        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            //buat cek error kalo ada field yang blm diisi
            bool kembar = false;
            bool notFilled = false;
            if (tB_TeamName.Text == string.Empty || tB_TeamCountry.Text == string.Empty || tB_TeamCity.Text == string.Empty)
            {
                notFilled = true;
            }
            //cek error kalo ada nama yang kembar
            for (int i = 0;i < soccerTeams.Count; i++)
            {
                if (tB_TeamName.Text == soccerTeams[i].teamName)
                {
                    kembar = true;
                }
            }
            //hasil cek dan add
            if(kembar == false && notFilled == false)
            {
                AddTeam(tB_TeamName.Text, tB_TeamCountry.Text, tB_TeamCity.Text);
                tB_TeamName.Clear();
                tB_TeamCountry.Clear();
                tB_TeamCity.Clear();
                cBox_ChooseCountry.SelectedItem = null;
            }
            else if (notFilled)
            {
                MessageBox.Show("All Fields Need to Be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (kembar)
            {
                MessageBox.Show("Team With A Same Name Found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tB_TeamName.Clear();
                tB_TeamCountry.Clear();
                tB_TeamCity.Clear();
                cBox_ChooseCountry.SelectedItem = null;
            }
        }

        private void btn_AddPlayer_Click(object sender, EventArgs e)
        {
            int i;
            bool notFilled = false;
            bool kembarNomor = false;
            bool kembarNama = false;
            if (cBox_ChooseTeam.SelectedItem != null && cBox_ChooseCountry.SelectedItem != null)
            {
                lBox_Player.Items.Clear();
                //i untuk index yang mau dipake sesuai syarat kalo team yang diselect sesuai
                for (i = 0; i < soccerTeams.Count; i++)
                {
                    if (soccerTeams[i].teamName == cBox_ChooseTeam.SelectedItem.ToString())
                    {
                        //cek field kosong
                        if (tB_PlayerName.Text == string.Empty || tB_PlayerNumber.Text == string.Empty || cBox_PlayerPosition.SelectedItem == null)
                        {
                            notFilled = true;
                        }
                        //cek nomor player kembar
                        for (int j = 0; j < soccerTeams[i].Players.Count; j++)
                        {
                            if ($"({tB_PlayerNumber.Text})" == soccerTeams[i].Players[j].playerNum)
                            {
                                kembarNomor = true;
                            }
                        }
                        //cek nama player kembar
                        for (int j = 0; j < soccerTeams[i].Players.Count; j++)
                        {
                            if ($"{tB_PlayerName.Text}," == soccerTeams[i].Players[j].playerName)
                            {
                                kembarNama = true;
                            }
                        }
                        //hasil cek
                        if (notFilled == false && kembarNomor == false && kembarNama == false)
                        {
                            soccerTeams[i].AddPemain($"({tB_PlayerNumber.Text})", $"{tB_PlayerName.Text},", cBox_PlayerPosition.SelectedItem.ToString());
                            tB_PlayerName.Clear();
                            tB_PlayerNumber.Clear();
                            cBox_PlayerPosition.SelectedItem = null;
                            break;
                        }
                        else if (notFilled)
                        {
                            MessageBox.Show("All Fields Need to Be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        }
                        else if (kembarNomor)
                        {
                            MessageBox.Show("Player With A Same Number Found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            tB_PlayerName.Clear();
                            tB_PlayerNumber.Clear();
                            cBox_PlayerPosition.SelectedItem = null;
                            break;
                        }
                        else if (kembarNama)
                        {
                            MessageBox.Show("Player With A Same Name Found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            tB_PlayerName.Clear();
                            tB_PlayerNumber.Clear();
                            cBox_PlayerPosition.SelectedItem = null;
                            break;
                        }
                    }
                }
                //untuk menampilkan player di list box yang sesuai
                for (int j = 0; j < soccerTeams[i].Players.Count; j++)
                {
                    if (tB_PlayerNumber != null)
                    {
                        lBox_Player.Items.Add(soccerTeams[i].Players[j].playerNum + " " +
                            soccerTeams[i].Players[j].playerName + " " +
                            soccerTeams[i].Players[j].playerPos);
                        lBox_Player.Sorted = true;
                    }
                }
            }
            else
            {
                MessageBox.Show("All Fields Need to Be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            // cek error remove jika player kurang dr 11
            string nomorPemain;
            int i;
            if (lBox_Player.Items.Count > 11 && lBox_Player.SelectedItem != null)
            {
                for (i = 0; i < soccerTeams.Count; i++)
                {
                    if (soccerTeams[i].teamName == cBox_ChooseTeam.SelectedItem.ToString())
                    {
                        //ambil nomor pemain dari list box yang mau di remove
                        string pemain = lBox_Player.SelectedItem as string;
                        nomorPemain = pemain.Substring(0,4);
                        soccerTeams[i].RemovePemain(nomorPemain);
                        break;
                    }
                }
                for (int j = 0; j < soccerTeams[i].Players.Count; j++)
                {
                    lBox_Player.Items.Remove(lBox_Player.SelectedItem);
                }

            }
            else
            {
                MessageBox.Show("Unable To Remove Player if Players less than equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lBox_Player.SelectedItem = null;
            }
        }
    }
}
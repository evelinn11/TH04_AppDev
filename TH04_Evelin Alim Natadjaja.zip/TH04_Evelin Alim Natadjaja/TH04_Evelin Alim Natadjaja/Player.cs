﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Evelin_Alim_Natadjaja
{
    internal class Player
    {
        public string playerName;
        public string playerNum;
        public string playerPos;

        public Player(string nama, string nomor, string pos)
        {
            playerName = nama;
            playerNum = nomor;
            playerPos = pos;
        }
    }
}

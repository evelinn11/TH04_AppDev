﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_Evelin_Alim_Natadjaja
{
    internal class Team
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<Player> Players = new List<Player>();
        Player dataPemain;

        public Team(string nama, string negara, string kota) 
        {
            teamName = nama;
            teamCountry = negara;
            teamCity = kota;
        }

        public void AddPemain(string nomor, string nama, string posisi)
        {
            dataPemain = new Player(nama, nomor, posisi);
            Players.Add(dataPemain);
        }

        public void RemovePemain(string nomor)
        {
            if (dataPemain.playerNum ==  nomor)
            {
                Players.Remove(dataPemain);
            }
        }
    }
}
